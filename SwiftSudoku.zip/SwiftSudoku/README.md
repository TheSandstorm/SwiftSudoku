# SwiftSudoku

This app solves Sukoku puzzles and creates some random ones to solve.

To run on windows use Swift on windows and use the build.json 